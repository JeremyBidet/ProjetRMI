import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.util.Calendar;
import java.util.HashMap;

import javax.xml.rpc.ServiceException;

import org.tempuri.ConverterSoapImpl;

public class Bank {
	
	private HashMap<String, Account> accounts;
	private final ConverterSoapImpl converter = new ConverterSoapImpl();
	
	public Bank(){
		this.accounts = new HashMap<String, Account>();	
	}
	
	public void addAccount(String login, double balance,String name, String firstname, String currency){
		accounts.put(login,new Account(login,balance,name,firstname,currency));
	}
	
	public void deleteAccount(String login){
		accounts.remove(login);
	}
	
	public boolean creditAccount(long login, String currency, double amount) throws ServiceException, RemoteException{
		Account current = accounts.get(login);
		if(current == null ){
			return false;
		}	
		current.creditAccount(converter.getConversionAmount(currency, current.getCurrency(), Calendar.getInstance(),new BigDecimal(amount)).doubleValue());

		return true;
	}
	
	
	public boolean debitAccount(long login, String currency, double amount) throws ServiceException, RemoteException{
		Account current = accounts.get(login);
		
		if(current == null){
			return false;
		}
		return current.debitAccount(converter.getConversionAmount(currency, current.getCurrency(), Calendar.getInstance(),new BigDecimal(amount)).doubleValue());
	}
	
	public double getBalance(long login, String currency) throws RemoteException, ServiceException{
		Account current = accounts.get(login);		
		return converter.getConversionAmount(current.getCurrency(), currency, Calendar.getInstance(), new BigDecimal(current.getBalance())).doubleValue();	
	}

}
