/**
 * ConverterSoapSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.tempuri;

public class ConverterSoapSkeleton implements org.tempuri.ConverterSoap, org.apache.axis.wsdl.Skeleton {
    private org.tempuri.ConverterSoap impl;
    private static java.util.Map _myOperations = new java.util.Hashtable();
    private static java.util.Collection _myOperationsList = new java.util.ArrayList();

    /**
    * Returns List of OperationDesc objects with this name
    */
    public static java.util.List getOperationDescByName(java.lang.String methodName) {
        return (java.util.List)_myOperations.get(methodName);
    }

    /**
    * Returns Collection of OperationDescs
    */
    public static java.util.Collection getOperationDescs() {
        return _myOperationsList;
    }

    static {
        org.apache.axis.description.OperationDesc _oper;
        org.apache.axis.description.FaultDesc _fault;
        org.apache.axis.description.ParameterDesc [] _params;
        _params = new org.apache.axis.description.ParameterDesc [] {
        };
        _oper = new org.apache.axis.description.OperationDesc("getCurrencies", _params, new javax.xml.namespace.QName("http://tempuri.org/", "GetCurrenciesResult"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://tempuri.org/", "ArrayOfString"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://tempuri.org/", "GetCurrencies"));
        _oper.setSoapAction("http://tempuri.org/GetCurrencies");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getCurrencies") == null) {
            _myOperations.put("getCurrencies", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getCurrencies")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tempuri.org/", "Currency"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tempuri.org/", "RateDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"), java.util.Calendar.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getCurrencyRate", _params, new javax.xml.namespace.QName("http://tempuri.org/", "GetCurrencyRateResult"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://tempuri.org/", "GetCurrencyRate"));
        _oper.setSoapAction("http://tempuri.org/GetCurrencyRate");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getCurrencyRate") == null) {
            _myOperations.put("getCurrencyRate", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getCurrencyRate")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tempuri.org/", "RateDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"), java.util.Calendar.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getCurrencyRates", _params, new javax.xml.namespace.QName("http://tempuri.org/", "GetCurrencyRatesResult"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://tempuri.org/", ">>GetCurrencyRatesResponse>GetCurrencyRatesResult"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://tempuri.org/", "GetCurrencyRates"));
        _oper.setSoapAction("http://tempuri.org/GetCurrencyRates");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getCurrencyRates") == null) {
            _myOperations.put("getCurrencyRates", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getCurrencyRates")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tempuri.org/", "CurrencyFrom"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tempuri.org/", "CurrencyTo"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tempuri.org/", "RateDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"), java.util.Calendar.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getConversionRate", _params, new javax.xml.namespace.QName("http://tempuri.org/", "GetConversionRateResult"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://tempuri.org/", "GetConversionRate"));
        _oper.setSoapAction("http://tempuri.org/GetConversionRate");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getConversionRate") == null) {
            _myOperations.put("getConversionRate", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getConversionRate")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tempuri.org/", "CurrencyFrom"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tempuri.org/", "CurrencyTo"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tempuri.org/", "RateDate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"), java.util.Calendar.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tempuri.org/", "Amount"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"), java.math.BigDecimal.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getConversionAmount", _params, new javax.xml.namespace.QName("http://tempuri.org/", "GetConversionAmountResult"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://tempuri.org/", "GetConversionAmount"));
        _oper.setSoapAction("http://tempuri.org/GetConversionAmount");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getConversionAmount") == null) {
            _myOperations.put("getConversionAmount", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getConversionAmount")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tempuri.org/", "Currency"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("getCultureInfo", _params, new javax.xml.namespace.QName("http://tempuri.org/", "GetCultureInfoResult"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://tempuri.org/", "GetCultureInfo"));
        _oper.setSoapAction("http://tempuri.org/GetCultureInfo");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getCultureInfo") == null) {
            _myOperations.put("getCultureInfo", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getCultureInfo")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tempuri.org/", "ds"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://tempuri.org/", ">>ConvertDataTableColumn>ds"), org.tempuri.ConvertDataTableColumnDs.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tempuri.org/", "TableIndex"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tempuri.org/", "ColumnName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tempuri.org/", "FromCurrency"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tempuri.org/", "ToCurrency"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("convertDataTableColumn", _params, new javax.xml.namespace.QName("http://tempuri.org/", "ds"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://tempuri.org/", ">>ConvertDataTableColumnResponse>ds"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://tempuri.org/", "ConvertDataTableColumn"));
        _oper.setSoapAction("http://tempuri.org/ConvertDataTableColumn");
        _myOperationsList.add(_oper);
        if (_myOperations.get("convertDataTableColumn") == null) {
            _myOperations.put("convertDataTableColumn", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("convertDataTableColumn")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
        };
        _oper = new org.apache.axis.description.OperationDesc("getLastUpdateDate", _params, new javax.xml.namespace.QName("http://tempuri.org/", "GetLastUpdateDateResult"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://tempuri.org/", "GetLastUpdateDate"));
        _oper.setSoapAction("http://tempuri.org/GetLastUpdateDate");
        _myOperationsList.add(_oper);
        if (_myOperations.get("getLastUpdateDate") == null) {
            _myOperations.put("getLastUpdateDate", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("getLastUpdateDate")).add(_oper);
    }

    public ConverterSoapSkeleton() {
        this.impl = new org.tempuri.ConverterSoapImpl();
    }

    public ConverterSoapSkeleton(org.tempuri.ConverterSoap impl) {
        this.impl = impl;
    }
    public java.lang.String[] getCurrencies() throws java.rmi.RemoteException
    {
        java.lang.String[] ret = impl.getCurrencies();
        return ret;
    }

    public java.math.BigDecimal getCurrencyRate(java.lang.String currency, java.util.Calendar rateDate) throws java.rmi.RemoteException
    {
        java.math.BigDecimal ret = impl.getCurrencyRate(currency, rateDate);
        return ret;
    }

    public org.tempuri.GetCurrencyRatesResponseGetCurrencyRatesResult getCurrencyRates(java.util.Calendar rateDate) throws java.rmi.RemoteException
    {
        org.tempuri.GetCurrencyRatesResponseGetCurrencyRatesResult ret = impl.getCurrencyRates(rateDate);
        return ret;
    }

    public java.math.BigDecimal getConversionRate(java.lang.String currencyFrom, java.lang.String currencyTo, java.util.Calendar rateDate) throws java.rmi.RemoteException
    {
        java.math.BigDecimal ret = impl.getConversionRate(currencyFrom, currencyTo, rateDate);
        return ret;
    }

    public java.math.BigDecimal getConversionAmount(java.lang.String currencyFrom, java.lang.String currencyTo, java.util.Calendar rateDate, java.math.BigDecimal amount) throws java.rmi.RemoteException
    {
        java.math.BigDecimal ret = impl.getConversionAmount(currencyFrom, currencyTo, rateDate, amount);
        return ret;
    }

    public java.lang.String getCultureInfo(java.lang.String currency) throws java.rmi.RemoteException
    {
        java.lang.String ret = impl.getCultureInfo(currency);
        return ret;
    }

    public org.tempuri.ConvertDataTableColumnResponseDs convertDataTableColumn(org.tempuri.ConvertDataTableColumnDs ds, int tableIndex, java.lang.String columnName, java.lang.String fromCurrency, java.lang.String toCurrency) throws java.rmi.RemoteException
    {
        org.tempuri.ConvertDataTableColumnResponseDs ret = impl.convertDataTableColumn(ds, tableIndex, columnName, fromCurrency, toCurrency);
        return ret;
    }

    public java.util.Calendar getLastUpdateDate() throws java.rmi.RemoteException
    {
        java.util.Calendar ret = impl.getLastUpdateDate();
        return ret;
    }

}
